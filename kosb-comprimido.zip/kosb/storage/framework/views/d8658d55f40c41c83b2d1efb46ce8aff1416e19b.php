

<?php $__env->startSection('contenido_admin'); ?>


<!-- Cards -->

<div class="cardBox">
    <div class="card">               
    <div>
        <div class="numbers" id="cant-public"></div>
        <div class="cardName">Publicaciones Totales</div>                   
    </div>
    <div class="iconBx">
       <ion-icon name="eye-outline"></ion-icon>
    </div>
   </div>  

    <div class="card">
    <div>
        <div class="numbers" id="cant-usuarios"></div>
        <div class="cardName">Total de Usuarios</div>                   
    </div>
    <div class="iconBx">
       <ion-icon name="people-circle-outline"></ion-icon>
    </div>
   </div>

    <div class="card">
    <div>
        <div class="numbers" id="reclamos-sin-R"></div>
        <div class="cardName">Reclamos sin Respuesta</div>                   
    </div>
    <div class="iconBx">
       <ion-icon name="document-text-outline"></ion-icon>
    </div>
   </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/servicios/usuariosService.js')); ?>"></script>
<script src="<?php echo e(asset('js/servicios/reclamosService.js')); ?>"></script>
<script src="<?php echo e(asset('js/servicios/publicacionesService.js')); ?>"></script>
<script src="<?php echo e(asset('js/cargar_admin_home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kosb\resources\views/home.blade.php ENDPATH**/ ?>