<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">


    <div class="w-full sm:max-w-md mt-1 mb-9 px-8 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kosb\resources\views/components/form-card.blade.php ENDPATH**/ ?>