
<?php $__env->startSection('contenido_admin'); ?>
    <h1>HOLAS</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kosb\resources\views/reclamos.blade.php ENDPATH**/ ?>