<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\kosb\resources\views/components/button.blade.php ENDPATH**/ ?>