

<?php $__env->startSection('contenido_admin'); ?>

<!-- HTML TABLA RESPONSIBA PARA EDITAR ZONAS-->

<input type="text" id="cod_admin_log" class="desaparecer-elemento" name="<?php echo e(Auth::user()->id); ?>">
<div class="hide-me-zonas-edicion" id="hide-me-zonas-edicion">
    <div class="edicion-zona" id="edicion-zona"> 

            <h1>Edicion De Valores</h1>
            <div class=main_user_admin>
                <form >
                    <div class="zona">                                        
                        <label class="label_zona">Ingrese Nuevo Valor</label> 
                        <input class="input_zona" type="text" id="nombre_zona"></br>
                    </div>

                    <td>
                        <span class="btn_editar_datos">
                            <a href="#" id="guardar">Guardar</a> 
                            <a href="#" id="cancelar">Cancelar</a>
                        </span>
                    </td>
                    </form>
                </div>
        
            </div>  

    </div>
</div>

<!-- HTML TABLA RESPONSIBA PARA EDITAR RUBROS-->





<!-- HTML TABLA RESPONSIBA PARA VER ZONAS -->

<div class="hide-me-zonas" id="hide-me-zonas">

<div class="table_responsive">
    <table id="tabla_zonas">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre De La Zona</th>
                <th>Codigo Administrador Editor</th>
                <th>Fecha Edicion</th>   
                <th>Acciones</th>
                
            </tr>
        </thead>
        <tbody id="contenedor_zonas"> 
            
        </tbody>
    </table>
</div>

</div>

<!-- HTML TABLA RESPONSIBA PARA VER RUBROS -->

<div class="hide-me-rubro" id="hide-me-rubro">

<div class="table_responsive">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre Del Rubro</th>
                <th>Codigo Administrador Editor</th>
                <th>Fecha Edicion</th>   
                <th>Acciones</th>
                
            </tr>
        </thead>
        <tbody id="contenedor_rubro"> 
            
        </tbody>
    </table>
</div>

</div>

<!-- HTML TABLA RESPONSIBA PARA VER DURACION -->


<div class="hide-me-duracion" id="hide-me-duracion">

<div class="table_responsive">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Titulo Duracion</th>
                <th>Codigo Administrador Editor</th>
                <th>Fecha Edicion</th>   
                <th>Acciones</th>
                
            </tr>
        </thead>
        <tbody id="contenedor_duracion"> 
            
        </tbody>
    </table>
</div>

</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/servicios/zonasService.js')); ?>"></script>
    <script src="<?php echo e(asset('js/servicios/rubrosService.js')); ?>"></script>
    <script src="<?php echo e(asset('js/servicios/duracionesService.js')); ?>"></script>    
    <script src="<?php echo e(asset('js/zonas_en_admin.js')); ?>"></script>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kosb\resources\views/zonas.blade.php ENDPATH**/ ?>