<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Duracion extends Model
{
    use HasFactory;
    protected $table = 'duraciones';
    //protected $primarykey = 'cod_duracion';
    
}
